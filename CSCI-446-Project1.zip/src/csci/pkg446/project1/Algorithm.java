package csci.pkg446.project1;

/**
 *
 * @author thechucklingatom
 */
public abstract class Algorithm {
    public abstract Graph SolveGraph(Graph graphToSolve);
}
