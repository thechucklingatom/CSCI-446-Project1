
package csci.pkg446.project1;

/**
 *
 * @author thechucklingatom
 */
public class ProblemSolver {
    public ProblemSolver(){
        
    }
    
    public Graph colorGraph(Graph graphToSolve, Algorithm solvingAlgorithm){
        return solvingAlgorithm.SolveGraph(graphToSolve);
    }
}
