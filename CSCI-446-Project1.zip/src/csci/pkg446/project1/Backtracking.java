package csci.pkg446.project1;

/**
 *
 * @author thechucklingatom
 */
public abstract class Backtracking extends Algorithm {
    public abstract Graph SolveGraph(Graph graphToSolve);
}
